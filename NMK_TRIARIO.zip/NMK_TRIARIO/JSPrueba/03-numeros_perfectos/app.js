// referencias HTML
const valor_campo = document.getElementById("val_num");
const result = document.getElementById("resultado");
const btnResultados = document.getElementById("btnResult");


let array_divisores = [];

const divisores = (numero_perfecto) => {

    for (let i = 1; i < numero_perfecto; i++) {

        if (numero_perfecto % i === 0){
            array_divisores.push(i);
        }
    }
}

const sumar_arr = (arr_nums) => {

    let total = 0;

    arr_nums.forEach(element => {
        total += element;
    });

    return total;
}

// Eventos.
btnResultados.addEventListener('click', () =>{
    
    let numero_perfecto = valor_campo.value;
    divisores(numero_perfecto);
    
    const suma_igual = sumar_arr(array_divisores);
    console.log(suma_igual);

    if ( suma_igual == numero_perfecto ){
        console.log(JSON.stringify(array_divisores));
        result.innerHTML = "El número " + numero_perfecto + " es perfecto " + JSON.stringify(array_divisores) + " = " + numero_perfecto;
        numero_perfecto = '';
        array_divisores = [];
    }else{
        result.innerHTML = "El número " + numero_perfecto + " no es perfecto.";
        numero_perfecto = '';
        array_divisores = [];
    }
});
