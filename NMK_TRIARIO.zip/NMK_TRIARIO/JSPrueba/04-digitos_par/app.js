
// Referencias HTML 
// referencias HTML
const valor_campo = document.getElementById("val_num");
const result = document.getElementById("resultado");
const btnResultados = document.getElementById("btnResult");

let contador = 0;
let flag = false;

function espar( x ) {
    // and binario
    return !( x & 1 );
}


// Eventos.
btnResultados.addEventListener('click', () =>{
    
    let numero = valor_campo.value;

    if (numero.length < 5 || numero.length > 5 ) return;

    const a = numero / 10;
    const ai = a.toString().indexOf(".");
    const aia = a.toString().substr(ai + 1, 1);
    flag = espar(aia);
    if (flag == true) contador +=1;

    const b = a / 10;
    const bi = b.toString().indexOf(".");
    const bib = b.toString().substr(bi + 1, 1);
    flag = espar(bib);
    if (flag == true) contador +=1;

    const c = b / 10;
    const ci = c.toString().indexOf(".");
    const cic = c.toString().substr(ci + 1, 1);
    flag = espar(cic);
    if (flag == true) contador +=1;

    const d = c / 10;
    const di = d.toString().indexOf(".");
    const did = d.toString().substr(di + 1, 1);
    flag = espar(did);
    if (flag == true) contador +=1;

    const e = d / 10;
    const ei = e.toString().indexOf(".");
    const eie = e.toString().substr(ei + 1, 1);
    flag = espar(eie);
    if (flag == true) contador +=1; 

    result.innerHTML = "El número " + numero +  " cuenta con :" + contador + "   pares";

    contador = 0;
    valor_campo.value = '';
});
