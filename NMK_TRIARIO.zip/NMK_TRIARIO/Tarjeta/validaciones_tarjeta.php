<?php

include_once("./partials/head.php");
?>
<div class="container mt-5">
    <h1>Resultados.</h1>
    <hr/>

<?php

$glbl_cod_error = 0;
$glbl_numero_tar = '';
$glb_fec_tar = '';


include_once("./feedback.php");

if (isset($_POST['num_tar']) && isset($_POST['fec_cad'])){
    
    global $glbl_numero_tar, $glb_fec_tar;
    $glbl_numero_tar = $_POST['num_tar'];
    $glb_fec_tar = $_POST['fec_cad'];
    validacion_tarjeta($_POST['num_tar'], $_POST['fec_cad']);
}

function validacion_tarjeta( $numero_tarjeta, $fecha ){

    global $glbl_cod_error, $glbl_numero_tar, $glb_fec_tar;
    validaciones_numero_tarjeta($numero_tarjeta);
    validacion_fecha_tarjeta($fecha);
    feedback($glbl_cod_error, $glbl_numero_tar, $glb_fec_tar);
}

function validaciones_numero_tarjeta($numero_tarjeta){

    $patron_exp_reg = "/^[0-9]{16}$/";
    $bool_num_correcto = false;
    global $glbl_cod_error;
    
    if (!preg_match($patron_exp_reg, $numero_tarjeta)) return $glbl_cod_error = 1;
    
    $num_init_tar = ['4', '13', '16'];

    for ($i=0; $i < count($num_init_tar) ; $i++) { 

        if ( comienza_con($numero_tarjeta, $num_init_tar[$i]) ){

            $bool_num_correcto = true;
            break;

        }else{
            $bool_num_correcto = false;
        }
    }

    if (!$bool_num_correcto) return $glbl_cod_error = 2;
}

function validacion_fecha_tarjeta($fecha_tar){
    
    global $glbl_cod_error;
    $fecha_split = explode('/', $fecha_tar);

    if(count($fecha_split) === 1) return $glbl_cod_error = 3;    

    $mes_tar = $fecha_split[0];
    $anio_cad = $fecha_split[1];

    if ( strlen($anio_cad) != 2 ) return $glbl_cod_error = 4;

    if ( !is_numeric($mes_tar) || !is_numeric($anio_cad)) return $glbl_cod_error = 5;
    
    if ($anio_cad < 6  || $anio_cad > 20 ) return $glbl_cod_error = 6;

    date_default_timezone_set('America/Bogota');
    $anio_actual = substr(date("Y"),0,2);

    if ($anio_cad < $anio_actual) return $glbl_cod_error = 7;

    if ($mes_tar > 12 ) return $glbl_cod_error = 8;
}

function comienza_con($cadena, $cadena_comenzar){

    $len = strlen($cadena_comenzar); 
    return (substr($cadena, 0, $len) === $cadena_comenzar);
}

?>

<a href="http://localhost/Tarjeta" >Ir al inicio.</a>

</div>