<?php

function feedback($cod_error, $num_tar, $fec_tar){

    if ($cod_error === 1 ): ?>
    
        <div class="alert alert-danger mt-2" role="alert">
            El número de Tarjeta debe contener 16 caracteres enteros.
        </div>
    
    <?php elseif ($cod_error === 2 ): ?>
    
        <div class="alert alert-danger mt-2" role="alert">
            La Tarjeta debe empezar por los siguientes números: (4,13,16).
        </div>
        
    <?php elseif ($cod_error === 3 ): ?>
    
        <div class="alert alert-danger mt-2" role="alert">
            Diligencie el campo Fecha de Caducidad.
        </div>
        
    <?php elseif ($cod_error === 4 ): ?>
    
        <div class="alert alert-danger mt-2" role="alert">
            El Año de Caducidad debe de ser de una longitud de dos (2) Caracteres.
        </div>

    <?php elseif ($cod_error === 5 ): ?>

        <div class="alert alert-danger mt-2" role="alert">
            Datos incorrectos para la Fecha de Caducidad.<br>
            <p>Ej:20/20</p>
        </div>
   
    <?php elseif ($cod_error === 6 ): ?>

        <div class="alert alert-danger mt-2" role="alert">
            Los dos digitos del Año de Caducidad No están entre 7 - 20.
        </div>

    <?php elseif ($cod_error === 7 ): ?>

        <div class="alert alert-danger mt-2" role="alert">
            El año de Caducidad es anterior al Actual.
        </div>

        
    <?php elseif ($cod_error === 8 ): ?>

        <div class="alert alert-danger mt-2" role="alert">
            El Mes de Caducidad es Incorrecto.
        </div>
            
    <?php elseif ($cod_error === 0 ): ?>
    
        <div class="alert alert-success mt-2" role="alert">
            <p>Se validó Correctamente La Tarjeta: <?php echo $num_tar ?> con CVV: <?php echo $fec_tar ?></p>
        </div>

    <?php endif ?>
    <?
}
?>