
<?php
include_once("./partials/head.php")
?>
<body>

    <div class="container mt-5">
        
        <h1>Validar Caducidad Tarjeta</h1>
        <hr />

        <form method="POST" action="validaciones_tarjeta.php">

            <div class="form-group">
                <label for="num_tar">Número de Tarjeta:</label>
                <input class="form-control" type="text" id="num_tar" name="num_tar" placeholder="9876342516282937" autocomplete="off"/>
            </div>

            <div class="form-group">
                <label for="fec_cad">Fecha de Caducidad:</label>
                <input class="form-control" type="text" id="fec_cad" name="fec_cad" autocomplete="off" placeholder="01/17"/>
            </div>

            <button type="submit" class="btn btn-primary" id="btnValTar">Validar Tarjeta</button>

        </form>
    </div>

</body>
</html>
