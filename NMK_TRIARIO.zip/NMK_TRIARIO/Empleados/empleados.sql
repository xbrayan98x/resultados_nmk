-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 05-12-2020 a las 23:14:48
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empleados`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_eliminar_emp` (IN `id_emp` INT)  BEGIN
	delete from t_empleados 
	where id = id_emp;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_empl_id` (IN `id_emp` INT)  BEGIN
	select te.id, te.nombre, te.apellido, te.depto_id, te.salario
    from t_empleados as te where te.id = id_emp;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_mostrar_datos` ()  BEGIN
	select 
		te.id,
    	te.nombre,
    	te.apellido,
    	td.depto_nombre,
    	te.salario
	from t_empleados as te, t_departamento as td 
	where te.depto_id = td.depto_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_mostrar_dptos` ()  BEGIN
	select 
		td.depto_id,
    	td.depto_nombre
	from t_departamento as td;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_mostrar_insert_emp` (IN `nombre` VARCHAR(45), IN `apellido` VARCHAR(45), IN `salario` VARCHAR(20), IN `dpto_id` VARCHAR(2))  BEGIN
	insert into t_empleados (nombre,
							apellido,
							salario,
                            depto_id)
			values (nombre,apellido,salario,dpto_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `prdb_updt_empl_id` (IN `id_emp` INT, IN `nombre` VARCHAR(45), IN `apellido` VARCHAR(45), IN `salario` DECIMAL, IN `depto_id` INT)  BEGIN
    
    UPDATE t_empleados
    SET nombre=nombre, 
    apellido=apellido, 
    salario=salario,
    depto_id = depto_id
    WHERE id = id_emp;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_departamento`
--

CREATE TABLE `t_departamento` (
  `depto_id` int(11) NOT NULL COMMENT 'Clave primaria',
  `depto_nombre` varchar(50) NOT NULL COMMENT 'Nombre empleado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='tabla de Departamentos.';

--
-- Volcado de datos para la tabla `t_departamento`
--

INSERT INTO `t_departamento` (`depto_id`, `depto_nombre`) VALUES
(1, 'produccion'),
(2, 'comercial'),
(3, 'sistemas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_empleados`
--

CREATE TABLE `t_empleados` (
  `id` int(11) NOT NULL COMMENT 'Clave primaria',
  `nombre` varchar(50) NOT NULL COMMENT 'Nombre empleado',
  `apellido` varchar(100) NOT NULL COMMENT 'Apellidos empleado',
  `salario` decimal(10,0) NOT NULL COMMENT 'Salario del empleado',
  `depto_id` int(11) NOT NULL COMMENT 'Clave Fóranea de Departamento'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='tabla de Empleados.';

--
-- Volcado de datos para la tabla `t_empleados`
--

INSERT INTO `t_empleados` (`id`, `nombre`, `apellido`, `salario`, `depto_id`) VALUES
(1, 'pepe', 'perez', '5000', 1),
(2, 'fulano', 'de tal', '1500', 1),
(3, 'pedro', 'perez', '3000', 2),
(4, 'juan', 'valdez', '1000', 2),
(5, 'luisa', 'ochoa', '18000', 3),
(10, 'brayan', 'rojas', '2000', 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `t_departamento`
--
ALTER TABLE `t_departamento`
  ADD PRIMARY KEY (`depto_id`);

--
-- Indices de la tabla `t_empleados`
--
ALTER TABLE `t_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `depto_id` (`depto_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `t_departamento`
--
ALTER TABLE `t_departamento`
  MODIFY `depto_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `t_empleados`
--
ALTER TABLE `t_empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria', AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `t_empleados`
--
ALTER TABLE `t_empleados`
  ADD CONSTRAINT `t_empleados_ibfk_1` FOREIGN KEY (`depto_id`) REFERENCES `t_departamento` (`depto_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
