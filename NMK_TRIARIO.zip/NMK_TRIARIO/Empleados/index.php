<?php

include_once('./controller/MaestroController.php');

$objMaestroController =new MaestroController();

if(!isset($_GET['codigo'])){

	$codigo=1;
}
else {

	$codigo=$_GET['codigo'];
}


if( $codigo == 1 ) {
	$objMaestroController->getListar();

}

if( $codigo == 2 ){

	$objMaestroController->getCrear();

}

if( $codigo == 3 ){

	$id=$_GET['id'];
	$objMaestroController->postEliminar($id);
}

if( $codigo == 4 ){

	$id=$_GET['id'];
	$objMaestroController->getActualizar($id);
}

?>