<!DOCTYPE html>
<html>
<head>
	<title>Actualizar Empleado</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
     integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
     crossorigin="anonymous"
    >
</head>
<body>

<?php

$objMaestroController =new MaestroController();
$result = $objMaestroController->getEmplById();

while (@$data_emp = mysqli_fetch_row($result) ) {
                                
    $nombre = $data_emp[1];
    $apellido = $data_emp[2];
    $salario = $data_emp[4];
}

?>

<div class="container mt-5">
    <h1>Actualizar Empleado</h1>
    <hr />
    <form method="post" action="./controller/Actualizar.php">

    <div class="form-group">
        <input type="hidden" class="form-control" id="txtId" 
        placeholder="Nombre" name="txtId" value="<?php echo $_GET['id'] ?>">
    </div>

    
    <div class="form-group">
        <label for="txtNombre">Nombre</label>
        <input type="text" class="form-control" id="txtNombre" 
        placeholder="Nombre" name="txtNombre" value="<?php echo $nombre ?>">
    </div>
  
    <div class="form-group">
        <label for="txtApellido">Apellido</label>
        <input type="text" class="form-control" id="txtApellido" 
        placeholder="Apellido" name="txtApellido" value="<?php echo $apellido?>">
    </div>
    
    <div class="form-group">
        <label for="txtNombre">Salario</label>
        <input type="text" class="form-control"
        id="txtSalario" placeholder="1000" name="txtSalario" value="<?php echo $salario ?>">
    </div>

    <div class="form-group">
        <label for="sltDpto">Seleccione Departamento</label>
        <select class="form-control" id="sltDpto" name="txtIdDptp">
        <?php
            $objMaestroController =new MaestroController();
            $result = $objMaestroController->getDeptos();

            while (@$lista_dptos = mysqli_fetch_row($result) ) {
                                
                echo '<option value="'.$lista_dptos[0].'">'.$lista_dptos[1].'</option>';
            }
        ?>
        </select>
    </div>

  <button type="submit" class="btn btn-primary">Actualizar</button>
</form>

    <h3><a href=index.php?codigo=1 class="btn btn-info mt-3">Ir al Inicio</a></h3>

</div>
</body>
</html