<!DOCTYPE html>
<html>
<head>
	<title>Empleados Mantenimiento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
     integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
     crossorigin="anonymous"
    >
</head>
<body>
<div class="container mt-4">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre Completo</th>
      <th scope="col">Departamento</th>
      <th scope="col">Salario</th>
      <th colspan="2">Operaciones</th>
    </tr>
  </thead>
  <tbody>
  <?php
        while (@$fet = mysqli_fetch_row($resultado)) {
            echo "<tr>
	        <th scope=row>".$fet[0]."</th>
	        <td>".$fet[1].' '.$fet[2]."</th>
            <td>".$fet[3]."</th>
            <td>".$fet[4]."</th>
            <th><a class='btn btn-danger' href=index.php?codigo=3&id=$fet[0]>Eliminar</a></th>
            <th><a class='btn btn-success' href=index.php?codigo=4&id=$fet[0]>Actualizar</a></th>
	        </tr>";
        }
    ?>
  </tbody>
</table>
<h3><a href=index.php?codigo=2 class="btn btn-primary">Agregar Empleado</a></h3>
</div>
</body>
</html>