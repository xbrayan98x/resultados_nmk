<!DOCTYPE html>
<html>
<head>
	<title>Registrar Empleado</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
     integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
     crossorigin="anonymous"
    >
</head>
<body>

<div class="container mt-5">
    <h1>Formulario de Resgistro</h1>
    <hr />
    <form method="post" action="./controller/Crear.php">
    
    <div class="form-group">
        <label for="txtNombre">Nombre</label>
        <input type="text" class="form-control" id="txtNombre" placeholder="Nombre" name="txtNombre">
    </div>
  
    <div class="form-group">
        <label for="txtApellido">Apellido</label>
        <input type="text" class="form-control" id="txtApellido" placeholder="Apellido" name="txtApellido">
    </div>
    
    <div class="form-group">
        <label for="txtNombre">Salario</label>
        <input type="text" class="form-control" id="txtSalario" placeholder="1000" name="txtSalario">
    </div>

    <div class="form-group">
        <label for="sltDpto">Seleccione Departamento</label>
        <select class="form-control" id="sltDpto" name="txtIdDptp">
        <?php
            $objMaestroController =new MaestroController();
            $result = $objMaestroController->getDeptos();

            while (@$lista_dptos = mysqli_fetch_row($result) ) {
                                
                echo '<option value="'.$lista_dptos[0].'">'.$lista_dptos[1].'</option>';
            }
        ?>
        </select>
    </div>

  <button type="submit" class="btn btn-primary">Regsitrar</button>
</form>

    <h3><a href=index.php?codigo=1 class="btn btn-info mt-3">Ir al Inicio</a></h3>

</div>
</body>
</html