<?php

class Conexion {

	private $host;
	private $user;
	private $password;
	private $database;
	private $conexion;

	function __construct(){

		$this->setConnect();
		$this->connect();
	}

	private function setConnect(){

		$this->host="localhost";
		$this->user="root";
		$this->password="";
		$this->database="empleados";
    }
    
	private function connect(){

		$this->conexion=mysqli_connect( $this->host, $this->user, $this->password ,$this->database );
		if (!$this->conexion) {
			die("no hubo conexion en la base de datos");
		}
	}
	public function getConnect(){

		return $this->conexion;
    }
    
	public function closeConnect(){
        
		mysqli_close($this->conexion);
	}
}

?>