<?php

include_once('./model/Conexion.php');

class MaestroController{

	public function getListar(){

		$objConexion =new Conexion();
		$sql = "CALL prdb_mostrar_datos";
        $resultado = mysqli_query($objConexion->getConnect(),$sql);
        include_once('./view/ListarEmpleados.php');
        $objConexion->closeConnect();
    }
    
    public function getDeptos(){

        $objConexion =new Conexion();
		$sql = "CALL prdb_mostrar_dptos";
        $resultado = mysqli_query($objConexion->getConnect(),$sql);
        $objConexion->closeConnect();
        return $resultado;
    }

	public function getCrear(){
		
		include_once('./view/Crear.php');
    }

    public function postEliminar($byId) {

        $objConexion = new Conexion();
        $sql = "CALL prdb_eliminar_emp('$byId')";
        $resultado = mysqli_query($objConexion->getConnect(),$sql);
        $objConexion->closeConnect();
		header("location:./index.php");
    }

    public function getActualizar($byId) {

        include_once("./view/Actualizar.php");
    }
    

    public function getEmplById(){

        $objConexion =new Conexion();
        $id = $_GET['id'];
		$sql = "CALL prdb_empl_id('$id')";
        $resultado = mysqli_query($objConexion->getConnect(),$sql);
        $objConexion->closeConnect();
        return $resultado;
    }
}

?>