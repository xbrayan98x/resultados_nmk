<?php

include_once '../model/Conexion.php';

$id = $_POST['txtId'];
$nombre = $_POST['txtNombre'];
$apellido = $_POST['txtApellido'];
$salario = $_POST['txtSalario'];
$depto_id = $_POST['txtIdDptp'];

$objConexion =new Conexion();
$sql="CALL prdb_updt_empl_id('$id','$nombre','$apellido','$salario', '$depto_id')";
$resultado = mysqli_query($objConexion->getConnect(),$sql);
$objConexion->closeConnect();


header("location:../index.php");

?>